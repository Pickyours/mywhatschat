<?php

return [
    /**
     * Server requirements
     */
    'php' => '8.2.0',
];
