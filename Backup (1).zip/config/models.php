<?php

return [
    [ 'value' => 'gpt-4o-audio-preview', 'label' => 'gpt-4o-audio-preview'],
    [ 'value' => 'gpt-4-turbo', 'label' => 'gpt-4-turbo' ],
    [ 'value' => 'gpt-4-turbo-2024-04-09', 'label' => 'gpt-4-turbo-2024-04-09' ],
    [ 'value' => 'chatgpt-4o-latest', 'label' => 'chatgpt-4o-latest' ],
    [ 'value' => 'gpt-4-turbo-preview', 'label' => 'gpt-4-turbo-preview' ],
    [ 'value' => 'gpt-4-0125-preview', 'label' => 'gpt-4-0125-preview' ],
    [ 'value' => 'gpt-3.5-turbo-0125', 'label' => 'gpt-3.5-turbo-0125' ],
    [ 'value' => 'gpt-3.5-turbo', 'label' => 'gpt-3.5-turbo' ],
    [ 'value' => 'o1-preview-2024-09-12', 'label' => 'o1-preview-2024-09-12' ],
    [ 'value' => 'o1-preview', 'label' => 'o1-preview' ],
    [ 'value' => 'gpt-4o-mini', 'label' => 'gpt-4o-mini' ],
    [ 'value' => 'gpt-4o-2024-05-13', 'label' => 'gpt-4o-2024-05-13' ],
    [ 'value' => 'gpt-4o-mini-2024-07-18', 'label' => 'gpt-4o-mini-2024-07-18' ],
    [ 'value' => 'gpt-4-1106-preview', 'label' => 'gpt-4-1106-preview' ],
    [ 'value' => 'gpt-3.5-turbo-16k', 'label' => 'gpt-3.5-turbo-16k' ],
    [ 'value' => 'gpt-4o', 'label' => 'gpt-4o' ],
    [ 'value' => 'gpt-4o-2024-08-06', 'label' => 'gpt-4o-2024-08-06' ],
    [ 'value' => 'gpt-3.5-turbo-1106', 'label' => 'gpt-3.5-turbo-1106' ],
    [ 'value' => 'gpt-4-0613', 'label' => 'gpt-4-0613' ],
    [ 'value' => 'o1-mini', 'label' => 'o1-mini' ],
    [ 'value' => 'gpt-4', 'label' => 'gpt-4' ],
    [ 'value' => 'o1-mini-2024-09-12', 'label' => 'o1-mini-2024-09-12' ]
];