<?php

return [
    [ 'value' => '/sounds/message-pop-alert.mp3', 'label' => 'Message pop alert' ],
    [ 'value' => '/sounds/long-pop.wav', 'label' => 'Long pop alert' ],
    [ 'value' => '/sounds/double-beep-tone.wav', 'label' => 'Double beep tone' ],
    [ 'value' => '/sounds/digital-quick-tone.wav', 'label' => 'Digital quick tone' ],
    [ 'value' => '/sounds/chime-pop.wav', 'label' => 'Fun chime pop' ],
];