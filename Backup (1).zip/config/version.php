<?php

return [
    'version' => '2.6', 
    'release_date' => '17th Jan 2024',
];