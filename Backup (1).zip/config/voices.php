<?php

return [
    [ 'value' => 'alloy', 'label' => 'alloy'],
    [ 'value' => 'echo', 'label' => 'echo' ],
    [ 'value' => 'fable', 'label' => 'fable' ],
    [ 'value' => 'onyx', 'label' => 'onyx' ],
    [ 'value' => 'nova', 'label' => 'nova' ],
    [ 'value' => 'shimmer', 'label' => 'shimmer' ]
];