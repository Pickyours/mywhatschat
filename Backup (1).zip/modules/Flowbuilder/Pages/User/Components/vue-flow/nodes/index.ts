export interface LLMNodeData {
  title: string
}

export interface LLMNodeEvents {}
